<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCustodiesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('custodies', function (Blueprint $table) {
            $table->id();
            $table->string('product_name');
            $table->string('serial_number');
            $table->tinyInteger('type')->comment('1 => desktop, 2 => laptop, 3 => printer, 4 => mobile, 5 => scanner, 6 => screen, 7 => headsets');
            $table->string('desc');
            $table->tinyInteger('condition')->comment('1 => new, 2 => used, 3 => damaged, 4 => missing, 5 => maintenance');
            $table->unsignedBigInteger('recipient_id')->nullable();
            $table->date('received_date')->nullable();
            $table->timestamps();
            $table->softDeletes();

            $table->foreign('recipient_id')->references('id')->on('users')->onDelete('set null');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('custodies');
    }
}

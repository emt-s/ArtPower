<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSectorsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('sectors', function (Blueprint $table) {
            $table->id('id');

            $table->text('title');
            $table->string('image')->nullable();
            $table->string('icon')->nullable();
            $table->string('slug');
            $table->text('desc')->nullable();
            $table->boolean('is_active')->default(1);
            $table->integer('order')->default('0');
            $table->integer('user_id')->nullable();


            // $table->string('title');
            // $table->text('description')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('sectors');
    }
}

<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Sector;
use Illuminate\Support\Str;


class SectorSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

        $secters = [
        	 [
        		'ar' => 'test 1',
        		'en' => 'test 1',
        	],
        	[
        		'ar' => 'test 2',
        		'en' => 'test 2',
        	],
        	[
        		'ar' => 'test 3',
        		'en' => 'test 3',
        	],
        	[
        		'ar' => 'test 4',
        		'en' => 'test 4',
        	],
        ];


        foreach ($secters as $secter) {
             Sector::create(['id'=> Str::uuid() ,'slug' => Str::slug($secter['en']) ,'title' => $secter]);
        }


    }
}

<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;

use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;

class CreateAdminUserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $user = User::create([
            //'id' => \Illuminate\Support\Str::uuid(),
            'name' => 'admin',
            'mobile' => '0540437879',
            'email' => 'a.alhadi@ad.net.sa',
            'google_id' => '11',
            'password' => '123456'
        ]);

        $role = Role::create(['name' => 'Admin']);

        $permissions = Permission::pluck('id', 'id')->all();

        $role->syncPermissions($permissions);

        $user->assignRole([$role->id]);

        $role1 = Role::create(['name' => 'Manager']);
        $role2 = Role::create(['name' => 'employee']);
    }
}

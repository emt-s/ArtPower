<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Permission\Traits\HasRoles;
use App;

class Sector extends Model
{
    public $incrementing = false;

    use HasRoles;

    protected $table = 'sectors';

    public $casts = ['title' => 'array', 'desc' => 'array'];

    public $fillable = ['title', 'desc', 'slug', 'image'];
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Custody extends Model
{
    use SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'product_name',
        'serial_number',
        'type',
        'desc',
        'condition',
        'recipient_id',
        'received_date'
    ];

    public function recipient()
    {
        return $this->belongsTo('App\Models\User', 'recipient_id');
    }
}

<?php

namespace App\Http\Livewire\Employees;

use Livewire\Component;

class Show extends Component
{
    public $user;

    public function render()
    {
        return view('livewire.employees.show');
    }
}

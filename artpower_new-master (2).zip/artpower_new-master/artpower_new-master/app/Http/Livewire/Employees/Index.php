<?php

namespace App\Http\Livewire\Employees;

use App\Models\User;
use Livewire\Component;
use Livewire\WithPagination;
use Spatie\Permission\Models\Role;

class Index extends Component
{
    use WithPagination;

    public $roles;
    public $name = '';
    public $employee_number = '';
    public $trashed = false;

    public function mount()
    {
        $this->roles = Role::pluck('name', 'name');
    }

    public function updating()
    {
        $this->resetPage();
    }

    public function render()
    {
        $usersQuery = User::query();

        if ($this->name) {
            $usersQuery->where('name', 'like', '%'. $this->name .'%');
        }
        if ($this->employee_number) {
            $usersQuery->where('employee_number', 'like', '%'. $this->employee_number .'%');
        }
        if ($this->trashed) {
            $usersQuery->onlyTrashed();
        }

        $users = $usersQuery->paginate(10);
        $users = [];

        return view('livewire.employees.index', compact('users'));
    }
}

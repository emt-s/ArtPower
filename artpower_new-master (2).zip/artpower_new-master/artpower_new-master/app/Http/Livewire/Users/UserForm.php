<?php

namespace App\Http\Livewire\Users;

use App\Models\User;
use Livewire\Component;
use Spatie\Permission\Models\Role;
use Illuminate\Support\Facades\Session;

class UserForm extends Component
{
    public $user;
    public $roles_data;
    public $name;
    public $email;
    public $mobile;
    public $password;
    public $confirm_password;
    public $roles;

    protected function rules()
    {
        $rules = [
            'name' => 'required',
            'email' => 'required|email|unique:users,email',
            'mobile' =>'required',
            'password' => 'required|min:6|same:confirm_password',
            'roles' =>'required|array',
        ];

        if ($this->user) {
            $rules['email'] = 'required|email|unique:users,email,' . $this->user->id;
            $rules['password'] = 'nullable|min:6|same:confirm_password';
        }

        return $rules;
    }

    public function mount($user=null)
    {
        if ($user) {
            $this->fill([
                'roles_data' => Role::pluck('name', 'id'),
                'name' => $user->name,
                'email' => $user->email,
                'mobile' => $user->mobile,
                'roles' => $user->roles->pluck('id'),
            ]);
        } else {
            $this->roles_data = Role::pluck('name', 'id');
        }
    }

    public function updated($propertyName)
    {
        $this->validateOnly($propertyName);
    }

    public function saveUser()
    {
        $data = $this->validate();

        $user = $this->user;
        if ($user) {
            $user->update($data);

            Session::flash('message', __('admin.update_success'));
        } else {
            $data['google_id'] = 1;
            $user = User::create($data);

            Session::flash('message', __('admin.create_success'));
        }

        $user->syncRoles($this->roles);

        Session::flash('status', __('admin.success'));

        redirect(route('admin.users.index'));
    }

    public function render()
    {
        return view('livewire.users.user-form');
    }
}

<?php

namespace App\Http\Livewire\Users;

use App\Models\User;
use Livewire\Component;
use Livewire\WithPagination;
use Spatie\Permission\Models\Role;

class GetUsers extends Component
{
    use WithPagination;

    public $roles;
    public $name = '';
    public $email = '';
    public $mobile = '';
    public $role = '';
    public $trashed = false;

    public function mount()
    {
        $this->roles = Role::pluck('name', 'name');
    }

    public function updating()
    {
        $this->resetPage();
    }

    public function render()
    {
        $usersQuery = User::query();

        if ($this->name) {
            $usersQuery->where('name', 'like', '%' . $this->name . '%');
        }
        if ($this->email) {
            $usersQuery->where('email', 'like', '%' . $this->email . '%');
        }
        if ($this->mobile) {
            $usersQuery->where('mobile', 'like', '%' . $this->mobile . '%');
        }
        if ($this->role) {
            $usersQuery->role($this->role);
        }
        if ($this->trashed) {
            $usersQuery->onlyTrashed();
        }

        $users = $usersQuery->paginate(2);

        return view('livewire.users.get-users', compact('users'));
    }
}

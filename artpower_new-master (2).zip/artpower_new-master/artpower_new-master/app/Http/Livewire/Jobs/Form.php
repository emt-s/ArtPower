<?php

namespace App\Http\Livewire\Jobs;

use App\Models\Job;
use App\Models\Sector;
use Livewire\Component;
use Illuminate\Support\Facades\Session;

class Form extends Component
{
    public $job, $title, $sector_id, $level, $sectors;

    public function mount($job = null)
    {
        if ($job) {
            $this->fill([
                'title.en' => $job->title['en'],
                'title.ar' => $job->title['ar'],
                'sector_id' => $job->sector_id,
                'level' => $job->level,
            ]);
        }
        $this->sectors = Sector::all();
    }

    protected function rules()
    {
        $rules = [
            'title.en' => 'required',
            'title.ar' => 'required',
            'sector_id' => 'required',
            'level' => 'required',
        ];

        return $rules;
    }

    public function updated($name)
    {
        $this->validateOnly($name);
    }

    public function save()
    {
        $data = $this->validate();

        $job = $this->job;
        if ($job) {
            $job->update($data);

            Session::flash('message', __('admin.update_success'));
        } else {
            $job = Job::create($data);

            Session::flash('message', __('admin.create_success'));
        }

        Session::flash('status', __('admin.success'));

        redirect(route('admin.jobs.index'));
    }

    public function render()
    {
        return view('livewire.jobs.form');
    }
}

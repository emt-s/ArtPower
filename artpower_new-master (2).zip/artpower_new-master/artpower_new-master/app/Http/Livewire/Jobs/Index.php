<?php

namespace App\Http\Livewire\Jobs;

use App\Models\Job;
use Livewire\Component;
use Livewire\WithPagination;

class Index extends Component
{
    use WithPagination;

    public $title = '';
    public $sort = '';
    public $trashed = false;

    public function updating()
    {
        $this->resetPage();
    }

    public function render()
    {
        $jobsQuery = Job::query();

        if ($this->title) {
            $jobsQuery->where('title', 'like', '%' . $this->title . '%');
        }
        if ($this->sort) {
            $jobsQuery->orderBy('id', $this->sort);
        }
        if ($this->trashed) {
            $jobsQuery->onlyTrashed();
        }

        $jobs = $jobsQuery->paginate(10);

        return view('livewire.jobs.index', compact('jobs'));
    }
}

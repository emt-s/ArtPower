<?php

namespace App\Http\Livewire\Custody;

use App\Models\Custody;
use Livewire\Component;
use Livewire\WithPagination;

class Index extends Component
{
    use WithPagination;

    public $search_title = '';
    public $type = '';
    public $condition = '';
    public $sort = '';
    public $trashed = false;

    public function updating()
    {
        $this->resetPage();
    }

    public function render()
    {
        $custodiesQuery = Custody::query();

        if ($this->search_title) {
            $custodiesQuery->where('product_name', 'like', '%' . $this->search_title . '%');
        }
        if ($this->type) {
            $custodiesQuery->where('type', $this->type);
        }
        if ($this->condition) {
            $custodiesQuery->where('condition', $this->condition);
        }
        if ($this->sort) {
            $custodiesQuery->orderBy('id', $this->sort);
        }
        if ($this->trashed) {
            $custodiesQuery->onlyTrashed();
        }

        $custodies = $custodiesQuery->paginate(10);

        return view('livewire.custody.index', compact('custodies'));
    }
}

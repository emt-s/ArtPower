<?php

namespace App\Http\Livewire\Custody;

use Livewire\Component;

class Create extends Component
{
    public function render()
    {
        return view('livewire.custody.create');
    }
}

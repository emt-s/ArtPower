<?php

namespace App\Http\Livewire\Custody;

use Livewire\Component;

class Edit extends Component
{
    public function render()
    {
        return view('livewire.custody.edit');
    }
}

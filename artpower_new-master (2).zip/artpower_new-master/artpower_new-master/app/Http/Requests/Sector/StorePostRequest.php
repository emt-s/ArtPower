<?php

namespace App\Http\Requests\Sector;

use Illuminate\Foundation\Http\FormRequest;

class StorePostRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'title'             => 'required|array',
            //'slug'              => 'required|unique:pages|max:255|min:3',
            'image'              => 'mimes:jpeg,png,jpg',
            'desc'              => 'required|array',
            'is_active'              => 'required',
        ];
    }
}

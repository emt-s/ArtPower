<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Validator;
use Session;
use Redirect;
use Illuminate\Support\Facades\Input;
use Carbon\Carbon;
use Auth;
use Config;
use App;
use Hash;
use App\User;

use App\Log;


class AdminController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }

    public function landingPage()
    {
        return view('admin.dashboard.index');
    }

    public function pm()
    {
        return view('admin.dashboard.pm');
    }

    public function hr()
    {
        return view('admin.dashboard.hr');
    }
}

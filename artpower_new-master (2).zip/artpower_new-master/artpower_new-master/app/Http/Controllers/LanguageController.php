<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Http\Requests;
use Config;
use App;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use Session;

class LanguageController extends Controller
{

    public function index() {

		if(!Session::has('locale')) {
			Session::put('locale', Input::get('locale'));
		}else{
			Session::put('locale', Input::get('locale')); 
		}
		return Redirect::back();
    }

    public function switchLang($lang)
    {

        if (array_key_exists($lang, Config::get('languages'))) {
            Session::put('locale', $lang);
            Session::save();
        }
        

        return Redirect::back();
    }
}

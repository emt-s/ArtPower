<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use App\Models\User;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Laravel\Socialite\Facades\Socialite;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{


    /**
     * Redirect the user to the Google authentication page.
     *
     * @return \Illuminate\Http\Response
     */
    public function redirectToProvider()
    {
        return Socialite::driver('google')->redirect();
    }

    /**
     * Obtain the user information from Google.
     *
     * @return \Illuminate\Http\Response
     */
    public function handleProviderCallback()
    {
        try {
            $user = Socialite::driver('google')->user();
        } catch (\Exception $e) {
            return redirect('/login');
        }
        // only allow people with @company.com to login
        if (explode("@", $user->email)[1] !== 'ad.net.sa') {
            //dd($user);
            return abort(403, 'Unauthorized action.');
        }
        // check if they're an existing user
        $existingUser = User::where('email', $user->email)->first();
        if ($existingUser) {
            auth()->login($existingUser, true);
            if (is_null($existingUser->sector)) {
                return redirect(route('admin.dashboard.landingPage'));
            } else {
                return redirect()->to('/home');
            }
        } else {
            $newUser                  = new User();
            // $newUser->id              = Str::uuid();
            $newUser->name            = $user->name;
            $newUser->password            = bcrypt($user->name);
            //$newUser->name_slug       = Str::slug(preg_replace('/\s+/', '', $user->name));
            $newUser->email           = $user->email;
            $newUser->google_id       = (string)$user->id;
            $newUser->avatar          = $user->avatar;
            $newUser->avatar_original = $user->avatar_original;


            //$newUser->group_id = Groups::findOrFail('bbe68548-675e-4f82-bb14-1da3e4fb3c35')->id;
            $newUser->save();

            Auth::login($newUser);

            return redirect(route('admin.dashboard.landingPage'));
        }
    }
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Sector;
use App\Models\User;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;


class EmployeeController extends Controller
{


    public function edit(Request $request)
    {
        try{

            $sectors = Sector::where('is_active',1)->get();

            return view('employee.profile')->withSectors($sectors);
        }
        catch (ModelNotFoundException $e)
        {
            redirect()->to('login/google')->withErrors(['errors_message' => ['Please sure your email under AD organization']]);
        }
    }


    public function update(Request $request)
    {

        $rule = [
            'id' => 'required',
            'employee_id' => 'required',
            'sector_id' => 'required',
            'avatar' => 'mimes:jpeg,png,jpg,gif,svg|max:2048'
        ];
        $messages = [
           'id.required' => 'In valid user',
           'employee_id.required' => 'Must Insert you Employee ID',
           'sector.required' => 'Must select you sector',
           'avatar.mimes' => 'Image extension is not allow. Please up image with those extensions jpeg,png,jpg,gif,svg only.',
           'avatar.max' => 'Image size must be less 2 MB.',
        ];

        $validator = Validator::make($request->all(), $rule, $messages);
         if($validator->fails())
         {
             return redirect()->back()
                 ->withErrors($validator)
                 ->withInput();
         }
         else {
             try {
                 $user = User::findOrFail($request->id);
                 $user->mobile = $request->mobile;
                 $user->name = $request->name;
                 $user->sector_id = $request->sector_id;
                 $user->job_title = $request->job_title;
                 $user->employee_id = $request->employee_id;

                 if ($request->hasFile('avatar')) {
                     $imageName = $user->id.'_'.time() . '.' . request()->avatar->getClientOriginalExtension();
                     request()->avatar->move(public_path('uploads/avatar'), $imageName);
                     $user->avatar = asset('uploads/avatar/'.$imageName);
                 }
                 $user->saveOrFail();
                 return redirect()->back()->with('success', 'You have successfully update profile.');

             } catch (ModelNotFoundException $e) {
                 redirect()->withErrors(['error_messages' => ['Technical error try again later!']])
                     ->withInput();
             }
         }
    }


}

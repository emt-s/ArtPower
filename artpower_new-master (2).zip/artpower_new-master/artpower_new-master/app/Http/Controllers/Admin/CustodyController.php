<?php

namespace App\Http\Controllers\Admin;

use App\Models\Custody;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Session;

class CustodyController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('admin.custodies.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.custodies.create');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Custody  $custody
     * @return \Illuminate\Http\Response
     */
    public function show(Custody $custody)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Custody  $custody
     * @return \Illuminate\Http\Response
     */
    public function edit(Custody $custody)
    {
        return view('admin.custodies.edit', compact('custody'));
    }

    /**
     * Soft delete the specified resource.
     *
     * @param  \App\Models\Custody  $custody
     * @return \Illuminate\Http\Response
     */
    public function destroy(Custody $custody)
    {
        $custody->delete();

        Session::flash('status', __('admin.danger'));
        Session::flash('message', __('admin.delete_success'));

        return redirect(route('admin.custodys.index'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function forceDelete($id)
    {
        $custody = Custody::withTrashed()->find($id);

        $custody->forceDelete();

        Session::flash('status', __('admin.danger'));
        Session::flash('message', __('admin.delete_success'));

        return redirect(route('admin.custodys.index'));
    }

    /**
     * Restore the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function restore(Request $request, $id)
    {
        $custody = Custody::withTrashed()->find($id);

        $custody->restore();

        Session::flash('status', __('admin.success'));
        Session::flash('message', __('admin.restore_success'));

        return redirect(route('admin.custodys.index'));
    }
}

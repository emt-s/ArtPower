<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Session;
use Redirect;
use Auth;
use Illuminate\Support\Str;


use App\Models\Sector;
use App\Models\Log;

use App\Http\Requests\Sector\StorePostRequest;
use App\Http\Requests\Sector\UpdatePostRequest;

use App\Notifications\Sector\Created;
use App\Notifications\Sector\Deleted;
use App\Notifications\Sector\Updated;
use App\Notifications\Sector\Restored;
use App\Notifications\Sector\Destroyed;

class SectorController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    // function __construct()
    // {
    //      $this->middleware('permission:sector-list|sector-create|sector-edit|sector-delete', ['only' => ['index','show']]);
    //      $this->middleware('permission:sector-create', ['only' => ['create','store']]);
    //      $this->middleware('permission:sector-edit', ['only' => ['edit','update']]);
    //      $this->middleware('permission:sector-delete', ['only' => ['destroy']]);
    //      $this->middleware('permission:sector-restore', ['only' => ['restore']]);
    // }


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        $sectors = Sector::paginate(10);

        return view('admin.sectors.index')->withSectors($sectors);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.sectors.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StorePostRequest $request)
    {


        $requests = $request->all();
        $requests['slug']  = Str::slug($requests['title']['en']);

        if (isset($requests['image'])) {
            $file = $requests['image'];
            $destinationPath = 'uploads/sectors';
            $extension =  $file->getClientOriginalExtension();
            $fileName = date("Y-m-d") . '-' . rand(999, 9999) . '.' . $extension;
            $upload_success = $file->move($destinationPath, $fileName);
            $requests['image'] =  $destinationPath . '/' . $fileName;
        }

        $sector = Sector::create($requests);


        if ($sector) {
            $log           = new Log;
            $log->user_id  = Auth::user()->id;
            $log->action   = 'create';
            $log->model    = 'sector';
            $log->url      = $request->server()['REQUEST_URI'];
            $log->ip       = $request->server()['REMOTE_ADDR'];
            $log->save();

            Auth::user()->notify(new Created($sector));
        }

        Session::flash('status', __('admin.success'));
        Session::flash('message', __('admin.create_success'));

        return redirect::to('/sectors');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        if (is_numeric($id)) {
            $sector = Sector::where('id', $id)->where('is_active', 1)->first();
        } else {
            $sector = Sector::where('slug', $id)->where('is_active', 1)->first();
        }

        return view('sectors.show')->withSector($sector);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $sector = Sector::find($id);

        return view('admin.sectors.edit')->withSector($sector);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdatePostRequest $request, $id)
    {

        $requests = $request->all();
        $requests['slug']  = Str::slug($requests['title']['en']);

        if (isset($requests['image'])) {
            $file = $requests['image'];
            $destinationPath = 'uploads/sectors';
            $extension =  $file->getClientOriginalExtension();
            $fileName = date("Y-m-d") . '-' . rand(999, 9999) . '.' . $extension;
            $upload_success = $file->move($destinationPath, $fileName);
            $requests['image'] =  $destinationPath . '/' . $fileName;
        }


        $sector = Sector::find($id);
        $sector = $sector->update($requests);

        $sector = Sector::find($id);


        if ($sector) {
            $log           = new Log;
            $log->user_id  = Auth::user()->id;
            $log->action   = 'update';
            $log->model    = 'sector';
            $log->url      = $request->server()['REQUEST_URI'];
            $log->ip       = $request->server()['REMOTE_ADDR'];
            $log->save();

            Auth::user()->notify(new Updated($sector));
        }


        Session::flash('status', __('admin.success'));
        Session::flash('message', __('admin.update_success'));
        return redirect::to('/sectors');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
    {

        $sector = Sector::find($id);

        if ($request->is_confirm) {

            if ($sector) {
                $log           = new Log;
                $log->user_id  = Auth::user()->id;
                $log->action   = 'destroy ';
                $log->model    = 'sector';
                $log->url      = $request->server()['REQUEST_URI'];
                $log->ip       = $request->server()['REMOTE_ADDR'];
                $log->save();
            }

            Auth::user()->notify(new Destroyed($sector));

            $sector->delete();
        } else {

            if ($sector) {
                $log           = new Log;
                $log->user_id  = Auth::user()->id;
                $log->action   = 'delete';
                $log->model    = 'sector';
                $log->url      = $request->server()['REQUEST_URI'];
                $log->ip       = $request->server()['REMOTE_ADDR'];
                $log->save();
            }

            Auth::user()->notify(new Deleted($sector));

            $sector->deleted_at = now();
            $sector->save();
        }




        Session::flash('status', __('admin.danger'));
        Session::flash('message', __('admin.delete_success'));

        return  redirect::to('/sectors');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function restore(Request $request, $id)
    {
        if (is_numeric($id)) {
            $sector = Sector::find($id);
        } else {
            $sector = Sector::where('slug', $id)->first();
        }

        if ($sector) {
            $log           = new Log;
            $log->user_id  = Auth::user()->id;
            $log->action   = 'restore';
            $log->model    = 'sector';
            $log->url      = $request->server()['REQUEST_URI'];
            $log->ip       = $request->server()['REMOTE_ADDR'];
            $log->save();
        }

        $sector->deleted_at = null;
        $sector->save();

        Auth::user()->notify(new Restored($sector));


        Session::flash('status', __('admin.success'));
        Session::flash('message', __('admin.restore_success'));

        return  redirect::to('/sectors');
    }
}

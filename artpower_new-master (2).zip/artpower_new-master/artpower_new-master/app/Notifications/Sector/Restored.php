<?php

namespace App\Notifications\Sector;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class Restored extends Notification
{
    use Queueable;

    protected $sector;

    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct($sector)
    {
        $this->sector = $sector;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        //return explode(',', $notifiable->notification_preference);
        return ['database'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toMail($notifiable)
    {
        return (new MailMessage)
                    ->line('The introduction to the notification.')
                    ->action('Notification Action', url('/'))
                    ->line('Thank you for using our application!');
    }



    public function toDatabase($notifiable)
    {

        return [
            'action'=> 'restore',
            'model'=> 'sectors',
            'model_id'=> $this->sector->id,
            'title'=>__('notification.SectorRestored'),
            'desc'=>__('notification.SectorRestoredDesc'),
        ];
    }


    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            //
        ];
    }
}

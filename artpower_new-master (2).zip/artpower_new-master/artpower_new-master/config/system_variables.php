<?php

return [

    'custody' => [

        'type' => [

            1 => 'desktop',
            2 => 'laptop',
            3 => 'printer',
            4 => 'mobile',
            5 => 'scanner',
            6 => 'screen',
            7 => 'headsets',

        ],

        'condition' => [

            1 => 'new',
            2 => 'used',
            3 => 'damaged',
            4 => 'missing',
            5 => 'maintenance',

        ],
    ],

];

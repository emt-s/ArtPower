<?php
	return [
	    'en' => 'English',
	    'ar' => 'عربي',
	];
?>